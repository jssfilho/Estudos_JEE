package br.com.ifpb.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ListaContatoServlet
 */
@WebServlet("/listarContatos")
public class ListaContatoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ListaContatoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		SimuladorBD banco = new SimuladorBD();
		List<Contato> lista = banco.getContatos();
		
		PrintWriter out = response.getWriter();
		out.println("<html><body>");
		out.println("<div>");
		
		for (Contato contato : lista) {
			out.println("<ul>");
			out.println("<li> " + contato.getName() + "</li>");
			out.println("<li> " + contato.getPhone() + "</li>");
			out.println("</ul> <br />");
		}

		out.println("<div />");
		out.println("<a href='/agenda/'>Voltar</a>");
		out.println("</body></html>");
	}
	

}
